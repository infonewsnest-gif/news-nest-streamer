package com.newsnest.streamer

import android.Manifest
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.pedro.common.ConnectChecker
import com.pedro.encoder.input.gl.render.filters.`object`.ImageObjectFilterRender
import com.pedro.encoder.input.sources.audio.MicrophoneSource
import com.pedro.encoder.input.sources.video.Camera2Source
import com.pedro.encoder.input.video.CameraHelper
import com.pedro.encoder.utils.gl.TranslateTo
import com.pedro.library.generic.GenericStream
import java.util.Locale

class MainActivity : AppCompatActivity(), ConnectChecker, SurfaceHolder.Callback {

    private companion object {
        const val FB_SERVER = "rtmps://live-api-s.facebook.com:443/rtmp/"
        const val YT_SERVER = "rtmp://a.rtmp.youtube.com/live2"
        const val REQ_PERMS = 100
    }

    private val needed = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)

    private lateinit var prefs: SharedPreferences
    private lateinit var surfaceView: SurfaceView
    private lateinit var aspectFrame: AspectFrameLayout
    private lateinit var tvStatus: TextView
    private lateinit var btnLive: Button
    private lateinit var btnDest: Button
    private lateinit var btnKeys: Button
    private lateinit var btnOrientation: Button
    private lateinit var btnQuality: Button
    private lateinit var btnSwitchCam: Button
    private lateinit var btnMic: Button
    private lateinit var btnLogo: Button
    private lateinit var btnHeadlineToggle: Button
    private lateinit var btnApply: Button
    private lateinit var etLabel: EditText
    private lateinit var etHeadline: EditText

    private val ui = Handler(Looper.getMainLooper())
    private var stream: GenericStream? = null
    private var overlayFilter: ImageObjectFilterRender? = null
    private var logoBitmap: Bitmap? = null
    private var surfaceReady = false
    private var micMuted = false
    private var liveStartMs = 0L
    private var lastBitrateKbps = 0L
    private var outW = 1080
    private var outH = 1920

    private val ticker = object : Runnable {
        override fun run() {
            val s = stream
            if (s != null && s.isStreaming) {
                val sec = (SystemClock.elapsedRealtime() - liveStartMs) / 1000
                tvStatus.text = String.format(Locale.US, "● LIVE %02d:%02d  •  %d kbps", sec / 60, sec % 60, lastBitrateKbps)
                ui.postDelayed(this, 1000)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("newsnest", Context.MODE_PRIVATE)

        // Lock the screen to the chosen orientation; if it differs, the activity is recreated.
        val wantPortrait = prefs.getBoolean("portrait", true)
        requestedOrientation = if (wantPortrait) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        val isPortraitNow = resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
        if (wantPortrait != isPortraitNow) return

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        surfaceView = findViewById(R.id.surfaceView)
        aspectFrame = findViewById(R.id.aspectFrame)
        tvStatus = findViewById(R.id.tvStatus)
        btnLive = findViewById(R.id.btnLive)
        btnDest = findViewById(R.id.btnDest)
        btnKeys = findViewById(R.id.btnKeys)
        btnOrientation = findViewById(R.id.btnOrientation)
        btnQuality = findViewById(R.id.btnQuality)
        btnSwitchCam = findViewById(R.id.btnSwitchCam)
        btnMic = findViewById(R.id.btnMic)
        btnLogo = findViewById(R.id.btnLogo)
        btnHeadlineToggle = findViewById(R.id.btnHeadlineToggle)
        btnApply = findViewById(R.id.btnApply)
        etLabel = findViewById(R.id.etLabel)
        etHeadline = findViewById(R.id.etHeadline)

        logoBitmap = BitmapFactory.decodeResource(resources, R.drawable.logo)
        etLabel.setText(prefs.getString("label", "ব্রেকিং"))
        etHeadline.setText(prefs.getString("headline", ""))

        surfaceView.holder.addCallback(this)
        setupButtons()
        refreshButtons()

        if (hasPerms()) initStream() else ActivityCompat.requestPermissions(this, needed, REQ_PERMS)
    }

    // ---------- permissions ----------

    private fun hasPerms() = needed.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERMS) {
            if (hasPerms()) initStream() else toast("ক্যামেরা ও মাইকের অনুমতি না দিলে লাইভ করা যাবে না")
        }
    }

    // ---------- stream setup ----------

    private fun initStream() {
        if (stream != null) return
        stream = GenericStream(this, this)
        if (!prepareStream()) toast("ভিডিও/অডিও এনকোডার চালু করা যায়নি")
        startPreviewIfPossible(surfaceView.width, surfaceView.height)
    }

    private fun prepareStream(): Boolean {
        val s = stream ?: return false
        val hd720 = prefs.getBoolean("hd720", false)
        val w = if (hd720) 1280 else 1920
        val h = if (hd720) 720 else 1080
        val bitrate = if (hd720) 2_800_000 else 4_500_000
        val rotation = CameraHelper.getCameraOrientation(this)
        val videoOk = s.prepareVideo(w, h, bitrate, rotation = rotation)
        val audioOk = s.prepareAudio(44100, true, 128_000)
        val rotated = rotation == 90 || rotation == 270
        outW = if (rotated) h else w
        outH = if (rotated) w else h
        aspectFrame.ratio = outW.toFloat() / outH.toFloat()
        return videoOk && audioOk
    }

    private fun startPreviewIfPossible(width: Int, height: Int) {
        val s = stream ?: return
        if (!surfaceReady) return
        if (!s.isOnPreview) s.startPreview(surfaceView)
        if (width > 0 && height > 0) s.getGlInterface().setPreviewResolution(width, height)
        if (overlayFilter == null) applyOverlay()
    }

    // ---------- overlay (logo + headline) ----------

    private fun applyOverlay() {
        val s = stream ?: return
        if (!s.isOnPreview) return
        val bmp = OverlayRenderer.render(
            outW,
            outH,
            logoBitmap,
            prefs.getBoolean("logoOn", true),
            prefs.getBoolean("headOn", true),
            prefs.getString("label", "ব্রেকিং") ?: "",
            prefs.getString("headline", "") ?: ""
        )
        var f = overlayFilter
        if (f == null) {
            f = ImageObjectFilterRender()
            overlayFilter = f
            s.getGlInterface().setFilter(f)
        }
        f.setImage(bmp)
        f.setScale(100f, 100f)
        f.setPosition(TranslateTo.CENTER)
    }

    // ---------- buttons ----------

    private fun setupButtons() {
        btnLive.setOnClickListener { toggleLive() }

        btnDest.setOnClickListener {
            if (isLive()) { toast("লাইভ চলার সময় বদলানো যাবে না"); return@setOnClickListener }
            val now = prefs.getString("dest", "fb")
            prefs.edit().putString("dest", if (now == "fb") "yt" else "fb").apply()
            refreshButtons()
        }

        btnKeys.setOnClickListener { showKeysDialog() }

        btnOrientation.setOnClickListener {
            if (isLive()) { toast("লাইভ চলার সময় বদলানো যাবে না"); return@setOnClickListener }
            val p = prefs.getBoolean("portrait", true)
            prefs.edit().putBoolean("portrait", !p).apply()
            requestedOrientation = if (!p) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        }

        btnQuality.setOnClickListener {
            if (isLive()) { toast("লাইভ চলার সময় বদলানো যাবে না"); return@setOnClickListener }
            val hd = prefs.getBoolean("hd720", false)
            prefs.edit().putBoolean("hd720", !hd).apply()
            recreate()
        }

        btnSwitchCam.setOnClickListener {
            (stream?.videoSource as? Camera2Source)?.switchCamera()
        }

        btnMic.setOnClickListener {
            val mic = stream?.audioSource as? MicrophoneSource ?: return@setOnClickListener
            micMuted = !micMuted
            if (micMuted) mic.mute() else mic.unMute()
            refreshButtons()
        }

        btnLogo.setOnClickListener {
            prefs.edit().putBoolean("logoOn", !prefs.getBoolean("logoOn", true)).apply()
            refreshButtons()
            applyOverlay()
        }

        btnHeadlineToggle.setOnClickListener {
            prefs.edit().putBoolean("headOn", !prefs.getBoolean("headOn", true)).apply()
            refreshButtons()
            applyOverlay()
        }

        btnApply.setOnClickListener {
            prefs.edit()
                .putString("label", etLabel.text.toString().trim())
                .putString("headline", etHeadline.text.toString().trim())
                .putBoolean("headOn", true)
                .apply()
            refreshButtons()
            applyOverlay()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(etHeadline.windowToken, 0)
            toast("হেডলাইন দেওয়া হয়েছে")
        }
    }

    private fun refreshButtons() {
        val dest = prefs.getString("dest", "fb")
        btnDest.text = if (dest == "fb") "গন্তব্য: ফেসবুক" else "গন্তব্য: ইউটিউব"
        btnOrientation.text = if (prefs.getBoolean("portrait", true)) "পোর্ট্রেট" else "ল্যান্ডস্কেপ"
        btnQuality.text = if (prefs.getBoolean("hd720", false)) "720p" else "1080p"
        btnMic.text = if (micMuted) "মাইক বন্ধ" else "মাইক চালু"
        btnLogo.text = if (prefs.getBoolean("logoOn", true)) "লোগো: চালু" else "লোগো: বন্ধ"
        btnHeadlineToggle.text = if (prefs.getBoolean("headOn", true)) "হেডলাইন: চালু" else "হেডলাইন: বন্ধ"
    }

    // ---------- going live ----------

    private fun isLive(): Boolean = stream?.isStreaming == true

    private fun toggleLive() {
        val s = stream
        if (s == null) {
            toast("আগে ক্যামেরা ও মাইকের অনুমতি দিন")
            if (!hasPerms()) ActivityCompat.requestPermissions(this, needed, REQ_PERMS)
            return
        }
        if (s.isStreaming) {
            stopLive()
            return
        }
        val dest = prefs.getString("dest", "fb")
        val server = prefs.getString(if (dest == "fb") "fbServer" else "ytServer", if (dest == "fb") FB_SERVER else YT_SERVER) ?: ""
        val key = prefs.getString(if (dest == "fb") "fbKey" else "ytKey", "") ?: ""
        if (server.isBlank() || key.isBlank()) {
            toast("আগে \"লাইভ কী সেটিং\"-এ সার্ভার ও স্ট্রিম কী দিন")
            showKeysDialog()
            return
        }
        val url = server.trim().trimEnd('/') + "/" + key.trim()
        if (!s.isOnPreview && surfaceReady) s.startPreview(surfaceView)
        tvStatus.text = "সংযোগ হচ্ছে..."
        btnLive.text = "লাইভ বন্ধ করুন"
        s.startStream(url)
    }

    private fun stopLive() {
        val s = stream
        if (s != null && s.isStreaming) s.stopStream()
        ui.removeCallbacks(ticker)
        btnLive.text = "লাইভ শুরু"
        tvStatus.text = "প্রস্তুত"
    }

    private fun showKeysDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        fun title(t: String) {
            box.addView(TextView(this).apply {
                text = t
                setTypeface(typeface, Typeface.BOLD)
                setPadding(0, dp(12), 0, 0)
            })
        }
        fun field(hint: String, key: String, def: String): EditText {
            val e = EditText(this)
            e.hint = hint
            e.setSingleLine(true)
            e.setText(prefs.getString(key, def))
            box.addView(e)
            return e
        }
        title("ফেসবুক")
        val fbS = field("সার্ভার URL", "fbServer", FB_SERVER)
        val fbK = field("স্ট্রিম কী", "fbKey", "")
        title("ইউটিউব")
        val ytS = field("সার্ভার URL", "ytServer", YT_SERVER)
        val ytK = field("স্ট্রিম কী", "ytKey", "")

        AlertDialog.Builder(this)
            .setTitle("লাইভ কী সেটিং")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("সেভ") { _, _ ->
                prefs.edit()
                    .putString("fbServer", fbS.text.toString().trim())
                    .putString("fbKey", fbK.text.toString().trim())
                    .putString("ytServer", ytS.text.toString().trim())
                    .putString("ytKey", ytK.text.toString().trim())
                    .apply()
                toast("সেভ হয়েছে")
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    // ---------- ConnectChecker (called from background threads) ----------

    override fun onConnectionStarted(url: String) {}

    override fun onConnectionSuccess() {
        runOnUiThread {
            liveStartMs = SystemClock.elapsedRealtime()
            btnLive.text = "লাইভ বন্ধ করুন"
            ui.removeCallbacks(ticker)
            ui.post(ticker)
        }
    }

    override fun onConnectionFailed(reason: String) {
        runOnUiThread {
            stopLive()
            toast("সংযোগ ব্যর্থ: $reason")
        }
    }

    override fun onNewBitrate(bitrate: Long) {
        lastBitrateKbps = bitrate / 1000
    }

    override fun onDisconnect() {
        runOnUiThread {
            ui.removeCallbacks(ticker)
            btnLive.text = "লাইভ শুরু"
            tvStatus.text = "প্রস্তুত"
        }
    }

    override fun onAuthError() {
        runOnUiThread {
            stopLive()
            toast("স্ট্রিম কী বা অনুমতিতে সমস্যা")
        }
    }

    override fun onAuthSuccess() {}

    // ---------- surface ----------

    override fun surfaceCreated(holder: SurfaceHolder) {}

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        surfaceReady = true
        startPreviewIfPossible(width, height)
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        surfaceReady = false
        val s = stream ?: return
        if (s.isOnPreview) s.stopPreview()
        overlayFilter = null
    }

    // ---------- lifecycle / helpers ----------

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        val s = stream
        if (s != null) {
            if (s.isStreaming) s.stopStream()
            if (s.isOnPreview) s.stopPreview()
            s.release()
        }
        stream = null
        super.onDestroy()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
