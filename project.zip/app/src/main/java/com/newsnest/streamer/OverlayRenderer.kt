package com.newsnest.streamer

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils

/** Draws logo + headline panel into one transparent bitmap the size of the stream frame. */
object OverlayRenderer {

    fun render(
        w: Int,
        h: Int,
        logo: Bitmap?,
        showLogo: Boolean,
        showHeadline: Boolean,
        label: String,
        headline: String
    ): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val portrait = w < h
        val unit = minOf(w, h) / 100f
        val m = unit * 3f

        if (showLogo && logo != null) {
            val lw = if (portrait) w * 0.38f else w * 0.20f
            val lh = lw * logo.height / logo.width
            val p = unit * 1.2f
            val back = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(235, 255, 255, 255) }
            c.drawRoundRect(RectF(m, m, m + lw + 2 * p, m + lh + 2 * p), unit * 1.5f, unit * 1.5f, back)
            val lp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            c.drawBitmap(logo, null, RectF(m + p, m + p, m + p + lw, m + p + lh), lp)
        }

        if (showHeadline && headline.isNotBlank()) {
            val maxLines = if (portrait) 3 else 2
            val bottomMargin = if (portrait) h * 0.08f else h * 0.05f
            val sidePad = unit * 2.2f
            val panelLeft = m
            val panelRight = w - m
            val textWidth = (panelRight - panelLeft - 2 * sidePad).toInt()

            val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                typeface = Typeface.DEFAULT_BOLD
            }
            var size = unit * 5.2f
            val minSize = unit * 2.8f
            var layout: StaticLayout
            while (true) {
                tp.textSize = size
                layout = buildLayout(headline, tp, textWidth, Int.MAX_VALUE)
                if (layout.lineCount <= maxLines || size <= minSize) break
                size -= unit * 0.3f
            }
            if (layout.lineCount > maxLines) {
                layout = buildLayout(headline, tp, textWidth, maxLines)
            }

            val padV = unit * 2f
            val panelH = layout.height + 2 * padV
            val panelBottom = h - bottomMargin
            val panelTop = panelBottom - panelH

            val panelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(225, 0, 0, 0) }
            c.drawRoundRect(RectF(panelLeft, panelTop, panelRight, panelBottom), unit * 1.5f, unit * 1.5f, panelPaint)

            c.save()
            c.translate(panelLeft + sidePad, panelTop + padV)
            layout.draw(c)
            c.restore()

            if (label.isNotBlank()) {
                val lp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.WHITE
                    typeface = Typeface.DEFAULT_BOLD
                    textSize = unit * 3.6f
                }
                val chipPadX = unit * 2.4f
                val chipPadY = unit * 1.0f
                val fm = lp.fontMetrics
                val textH = fm.descent - fm.ascent
                val chipH = textH + 2 * chipPadY
                val chipW = lp.measureText(label) + 2 * chipPadX
                val chipLeft = panelLeft + unit * 2f
                val chipTop = panelTop - chipH
                val chipPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#D50000") }
                c.drawRoundRect(RectF(chipLeft, chipTop, chipLeft + chipW, chipTop + chipH + unit), unit, unit, chipPaint)
                c.drawText(label, chipLeft + chipPadX, chipTop + chipPadY - fm.ascent, lp)
            }
        }
        return bmp
    }

    private fun buildLayout(text: String, paint: TextPaint, width: Int, maxLines: Int): StaticLayout {
        val b = StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setIncludePad(false)
        if (maxLines != Int.MAX_VALUE) {
            b.setMaxLines(maxLines).setEllipsize(TextUtils.TruncateAt.END)
        }
        return b.build()
    }
}
